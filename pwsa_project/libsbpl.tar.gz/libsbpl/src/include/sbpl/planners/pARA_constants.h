#ifndef PARA_CONST
#define PARA_CONST
#define INITIAL_EPS 1.5
#define NUM_THREADS 24
#endif
